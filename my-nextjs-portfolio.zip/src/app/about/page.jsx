
'use client'
import React, { useState } from 'react';
import lightWork from '../../assets/tech.png'
import darkWork from '../../assets/darkmode.png'
import Image from 'next/image';
// Framer Motion ইমপোর্ট করা হয়েছে
import { motion } from 'framer-motion';

const AboutMe = () => {
    const handleDownloadCv = () => {
        const cvUrl = "/Eyasin-frontend-resume.pdf";
        const link = document.createElement("a");
        link.href = cvUrl;
        link.setAttribute("download", "Eyasin-frontend-resume.pdf");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const [isExpanded, setIsExpanded] = useState(false);

    const introductoryText = " Hi Everyone, This is Eyasin Arafat — a Full Stack Developer. My love for technology goes beyond profession; it is a part of who I am. On the frontend, I weave responsive and vibrant user interfaces using React, JavaScript, Tailwind CSS and also Elementor, Plugins—where beauty is not just seen, but felt."

    const hiddenText = "On the backend, I build a strong foundation with Node.js and Express.js, creating a secure and high-performance ecosystem that brings together RESTful APIs, JWT authentication and WebSockets. I don't just write code—I fight against threats like XSS, control traffic with rate limiting to prepare applications for takeoff on a production-ready platform. I ensure an SEO-friendly structure in every project, helping them rank higher in search engines. To me, every project is like a living entity—where the elegance of the frontend and the power of the backend come together in perfect harmony. My goal is not just to build applications, but to create fast, secure, and user-friendly web experiences that touch people's lives, grow businesses, and make the digital world more beautiful, faster, and more reliable.Passionate about transforming design concepts into seamless, scalable WordPress solutions with a strong focus on clean code and user experience."

    const infoData = [
        { label: "Name", value: "Eyasin Arafat" },
        { label: "Birthday", value: "21 Feb 2005" },
        { label: "Job", value: "Full Stack Developer" },
        { label: "Email", value: "eyasinwebdev@gmail.com" },
        { label: "Nick Name", value: "Eyasin" },
    ];

    const fadeInUp = {
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
    };

    const fadeInLeft = {
        hidden: { opacity: 0, x: -40 },
        visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: "easeOut" } }
    };

    const fadeInRight = {
        hidden: { opacity: 0, x: 40 },
        visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: "easeOut" } }
    };

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: { staggerChildren: 0.1 }
        }
    };

    return (
        <motion.section
            id='about'
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            variants={fadeInUp}
            className="w-[92%] max-w-full overflow-hidden mt-10 md:mt-0 mx-auto shadow-lg rounded-3xl bg-gradient-to-br from-pink-100 via-slate-100 dark:from-black dark:via-slate-800 transition-colors duration-500"
        >
            <div className="w-full mx-auto flex flex-col lg:flex-row gap-12 items-start">

                {/* Left (Image & Timeline) - Fade In Left */}
                <motion.div variants={fadeInLeft} className="w-full lg:w-1/3 flex flex-col items-center lg:items-start ">
                    {/* Illustration Image */}
                    <div className="w-full overflow-hidden rounded-tl-3xl rounded-tr-3xl md:rounded-tr-sm md:rounded-tl-3xl">
                        {/* Light Mode Image */}
                        <Image
                            src={lightWork}
                            alt="Developer Illustration"
                            className="w-full h-65 object-cover block dark:hidden transition-transform duration-500 hover:scale-105"
                        />
                        {/* Dark Mode Image */}
                        <Image
                            src={darkWork}
                            alt="Developer Illustration Dark"
                            className="w-full h-65 object-cover hidden dark:block transition-transform duration-500 hover:scale-105"
                        />
                    </div>

                    {/* Timeline Info */}
                    <div className='flex flex-col md:pl-8 pt-5 dark:pt-8'>
                        <motion.div variants={containerVariants} className="relative border-l-2 border-red-500 ">
                            {infoData.map((item, index) => (
                                <motion.div
                                    key={index}
                                    variants={fadeInLeft}
                                    className="mb-3 ml-6 relative"
                                >
                                    {/* Red Dot */}
                                    <div className="absolute h-3.5 w-3.5 mt-1.5 -left-8 bg-red-500 rounded-full border-2 border-white dark:border-white/80"></div>

                                    <p className="text-gray-800">
                                        <span className="font-semibold text-lg text-black dark:text-orange-500">
                                            {item.label}:
                                        </span>
                                        {item.label === "Email" ? (
                                            <a
                                                href={`mailto:${item.value}`}
                                                className="text-[16px] text-black ml-2 dark:text-white hover:text-red-500 underline transition-colors"
                                            >
                                                {item.value}
                                            </a>
                                        ) : (
                                            <span className="text-[16px] ml-2 text-black dark:text-white">
                                                {item.value}
                                            </span>
                                        )}
                                    </p>
                                </motion.div>
                            ))}
                        </motion.div>
                    </div>

                    {/* Download Button with subtle pulse hover */}
                    <motion.button
                        onClick={handleDownloadCv}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.98 }}
                        className="relative inline-flex items-center justify-center p-[2px] rounded-full overflow-hidden group ml-8 m-5 cursor-pointer"
                    >
                        {/* Animated Red Gradient Border */}
                        <span className="absolute inset-0 rounded-full bg-[conic-gradient(from_180deg,#ea580c,#fdba74,#f97316,#ea580c)] animate-[spin_4s_linear_infinite] opacity-90 group-hover:opacity-100 blur-[0.4px]"></span>

                        {/* Soft Red Glow */}
                        <span className="absolute inset-0 rounded-full bg-red-500/20 blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500"></span>

                        {/* Button Content */}
                        <span className="relative z-10 flex items-center gap-2 px-3.5 sm:px-5 py-2.5 sm:py-3 rounded-full bg-gradient-to-r from-red-600 to-red-500 border-2 text-white font-bold tracking-wide transition-all duration-300 group-hover:from-red-500 group-hover:to-red-600 shadow-[0_12px_35px_rgba(220,38,38,0.45)] whitespace-nowrap text-xs sm:text-base">
                            {/* Icon */}
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 transition-transform duration-300 group-hover:translate-y-0.5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16" />
                            </svg>
                            Download Resume
                        </span>
                    </motion.button>
                </motion.div>

                {/* Right (Content) - Fade In Right */}
                <motion.div variants={fadeInRight} className="w-full lg:w-2/3 md:pr-10 ">
                    <div className="w-fit">
                        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0F172A] text-center md:text-left p-5 md:pl-4 dark:text-white/75 light:text-black">
                            About Me— <span className="text-red-600 decoration-red-500 dark:text-red-500">Developing Journey</span>
                        </h2>
                        {/* Animated underline reveal */}
                        <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: "92%" }}
                            transition={{ duration: 0.8, delay: 0.3 }}
                            viewport={{ once: true }}
                            className="h-0.5 mb-4 md:mb-8 bg-red-500 mx-auto md:mx-4"
                        ></motion.div>
                    </div>

                    <div className="text-gray-500 leading-relaxed space-y-3 md:space-y-6 text-lg text-justify p-5">
                        <p className='text-[16px] leading-relaxed dark:text-white/65 light:text-black'>
                            {introductoryText}

                            <span className={`${isExpanded ? 'inline' : 'hidden'} md:inline`}>
                                {hiddenText}
                            </span>

                            {/* Device show/hidden condition */}
                            <span className={`${isExpanded ? 'hidden' : 'inline'} md:hidden`}>
                                ....
                            </span>
                        </p>

                        <button
                            onClick={() => setIsExpanded(!isExpanded)}
                            className="mt-2 bg-[#FF5A5F] text-white px-5 py-1 rounded-full font-semibold md:hidden">
                            {isExpanded ? "See less" : "See more"}
                        </button>

                        <p className='text-[16px] dark:text-white/65 light:text-black'>
                            I focus on clean architecture, smooth performance, and a polished user experience. Every line of code I write is aimed at solving real-world problems with reliability, security, and speed.
                        </p>
                    </div>
                </motion.div>

            </div>
        </motion.section>
    );
};

export default AboutMe;