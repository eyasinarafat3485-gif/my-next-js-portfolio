'use client'
import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { BiX, BiHomeAlt, BiUser, BiCodeBlock, BiBriefcase, BiPhone } from 'react-icons/bi';
import ThemeToggle from '../ThemeToggle';
import { RiMenu3Fill } from 'react-icons/ri';

const navLinks = [
  { id: 1, name: "Home", path: "/", icon: <BiHomeAlt /> },
  { id: 2, name: "About", path: "/#about", icon: <BiUser /> },
  { id: 4, name: "Projects", path: "/#projects", icon: <BiBriefcase /> },
  { id: 3, name: "Services", path: "/#services", icon: <BiCodeBlock /> },
  { id: 5, name: "Contact", path: "/#contact", icon: <BiPhone /> }
];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [activePath, setActivePath] = useState("/");
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();

  // ADD THIS
  const menuRef = useRef(null);

  useEffect(() => {
    setActivePath(pathname);

    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    // ADD THIS
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setOpen(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    // ADD THIS
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      window.removeEventListener('scroll', handleScroll);

      // ADD THIS
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [pathname]);

  return (
    <nav className={` text-black  dark:text-white transition-all duration-200 sticky left-0 w-full h-20 z-[100] flex items-center transition-all ease-in-out ${scrolled ? '' : 'bg-transparent'
      }`}>

      {/* ADD ref HERE */}
      <div ref={menuRef} className='relative z-10 flex justify-between items-center w-full max-w-7xl mx-auto px-4 md:px-12'>

        {/* Logo Section */}
        <div className='flex items-center gap-3'>
          <Link
            href="/"
            onClick={() => setActivePath("/")}
            className="flex items-center justify-center shadow-lg shadow-red-500/30 transition-all duration-200 hover:scale-105 shrink-0">
            <img src="/Ea-logo.png" alt="EA Logo" className="w-7 h-7 object-contain" />
          </Link>

          <Link href="/" onClick={() => setActivePath("/")} className='text-xl font-bold tracking-tight uppercase truncate text-gray-800 dark:text-white transition-colors duration-200'>
            Eyasin Arafat
          </Link>
        </div>

        {/* Desktop Menu */}
        <ul className='hidden md:flex gap-6 lg:gap-8 font-medium'>
          {navLinks.map((link) => (
            <li key={link.id}>
              <Link
                href={link.path}
                onClick={() => setActivePath(link.path)}
                className={`flex items-center gap-2 transition-colors text-lg ${activePath === link.path
                  ? 'text-red-500 font-bold hover:border-b-2 border-red-500 rounded-lg'
                  : 'text-gray-800 dark:text-white hover:border-b-2 border-red-500 rounded-lg'
                  }`}
              >
                <span className='hidden lg:block text-xl'>{link.icon}</span>
                <span>{link.name}</span>
              </Link>

            </li>
          ))}
          <ThemeToggle />
        </ul>

        {/* Mobile Menu Icon */}
        <div className='md:hidden flex items-center'>
          <button onClick={() => setOpen(!open)} className='text-3xl text-black dark:text-white focus:outline-none'>
            {open ? <BiX className='text-red-500 size-8' /> : <RiMenu3Fill />}
          </button>
        </div>

        {/* Mobile Dropdown Menu */}
        <ul className={`
          md:hidden absolute right-3 w-35 bg-gradient-to-br from-pink-100 via-slate-100 dark:from-black dark:via-slate-800 backdrop-blur-xl border border-red-50 flex flex-col gap-1 shadow-2xl rounded-md transition-all duration-200 ease-in-out
          ${open ? 'top-[45px] opacity-100 visible' : 'top-[45px] opacity-0 invisible'}
        `}>
          {navLinks.map((link) => (
            <li key={link.id} onClick={() => { setOpen(false); setActivePath(link.path); }}>
              <Link
                href={link.path}
                className={`flex items-center gap-2 text-base font-medium p-1 rounded-md transition-colors
                ${activePath === link.path ? 'text-red-500 bg-red-50 dark:bg-black font-bold' : 'text-gray-400 hover:bg-red-50 hover:text-red-500'}`}
              >
                <span className='text-xl'>{link.icon}</span>
                {link.name}
              </Link>
            </li>
          ))}
          <ThemeToggle />
        </ul>

      </div>
    </nav>
  );
};

export default Navbar;
