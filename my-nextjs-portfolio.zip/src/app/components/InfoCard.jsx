import { Mail, MapPin, Phone } from 'lucide-react';

const InfoCard = () => {
  return (
    <div className="flex flex-col gap-6 order-1 lg:order-2">
      {/* Phone Card */}
      <div className="bg-white dark:bg-black p-8 rounded-2xl shadow-sm border-[1.5px] border-gray-100 hover:border-red-500 transition-colors duration-500 flex flex-col items-center text-center">
        <div className="bg-red-50 dark:bg-slate-500/70 p-3 rounded-full mb-4">
          <Phone className="text-red-500 w-6 h-6" />
        </div>
        <h3 className="font-bold text-gray-800 dark:text-orange-500 mb-2">Phone</h3>
        <p className="text-gray-500 dark:text-white/75 text-sm leading-relaxed">
          <a
            href="tel:+8801304513475"
            className="hover:text-red-500 transition-colors"
          >
            +880 1304 513475
          </a>
          <br />
          <a
            href="tel:+8801960421858"
            className="hover:text-red-500 transition-colors"
          >
            +880 1960 421858
          </a>
          <br />
        </p>

        <div className="flex items-center justify-center mx-auto gap-1.5 sm:gap-2 text-[11px] sm:text-xs font-medium pt-2 whitespace-nowrap">
          <span className="w-[7px] h-[7px] sm:w-[8px] sm:h-[8px] shrink-0 rounded-full bg-blue-500 shadow-[0_0_15px_#22c55e] animate-pulse" />
          <p className='text-gray-500 dark:text-white/75 text-[11px] sm:text-xs font-medium whitespace-nowrap'>Available 9:00 AM – 10:00 PM (GMT+6 / UTC+6)</p>
        </div>
      </div>

      {/* Email Card */}
      <div className="bg-white dark:bg-black p-8 rounded-2xl shadow-sm border-[1.5px] border-gray-100 hover:border-red-500 transition-colors duration-500 flex flex-col items-center text-center">
        <div className="bg-red-50 dark:bg-slate-500/70 p-3 rounded-full mb-4">
          <Mail className="text-red-500 w-6 h-6" />
        </div>
        <h3 className="font-bold text-gray-800 dark:text-orange-500 mb-2">Email</h3>
        <p className="text-gray-500 dark:text-white/75 text-sm leading-relaxed">
          <a
            href="mailto:eyasinwebdev@gmail.com"
            className="text-[16px] text-black dark:text-white hover:text-red-500 underline transition-colors"
          >
            eyasinwebdev@gmail.com
          </a>
          <br />
        </p>

        <div className="flex items-center justify-center mx-auto gap-1.5 sm:gap-2 text-[11px] sm:text-xs font-medium pt-2 whitespace-nowrap">
          <span className="w-[7px] h-[7px] sm:w-[8px] sm:h-[8px] shrink-0 rounded-full bg-orange-500 shadow-[0_0_15px_#22c55e] animate-pulse" />
          <p className='text-gray-500 dark:text-white/75 text-[11px] sm:text-xs font-medium whitespace-nowrap'>Reply within 24 hours</p>
        </div>
      </div>

      {/* Location Card */}
      <div className="bg-white dark:bg-black p-8 rounded-2xl shadow-sm border-[1.5px] border-gray-100 hover:border-red-500 transition-colors duration-500 flex flex-col items-center text-center">
        <div className="bg-red-50 dark:bg-slate-500/70 p-3 rounded-full mb-4">
          <MapPin className="text-red-500 w-6 h-6" />
        </div>
        <h3 className="font-bold text-gray-800 dark:text-orange-500 mb-2">Location</h3>
        <p className="text-gray-500 dark:text-white/75 text-sm leading-relaxed">
          <a
            href="https://www.google.com/maps/search/?api=1&query=Mymensingh,+Bangladesh"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-red-500 underline transition-colors"
          >
            Mymenshing, Bangladesh
          </a>
          <br />
        </p>

        <div className="flex items-center justify-center mx-auto gap-1.5 sm:gap-2 text-[11px] sm:text-xs font-medium pt-2 whitespace-nowrap">
          <span className="w-[7px] h-[7px] sm:w-[8px] sm:h-[8px] shrink-0 rounded-full bg-green-500 shadow-[0_0_15px_#22c55e] animate-pulse" />
          <p className='text-gray-500 dark:text-white/75 text-[11px] sm:text-xs font-medium whitespace-nowrap'>Available for <span className='font-extrabold'>REMOTE</span> Work Worldwide</p>
        </div>
      </div>
    </div>
  );
};

export default InfoCard;